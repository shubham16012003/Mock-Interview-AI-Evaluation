import React, { useState } from 'react';
import { FiUpload, FiFile, FiCheckCircle } from 'react-icons/fi';
import axios from 'axios';
import './ResumeUploader.css';

const ResumeAnalysis = () => {
  const [file, setFile] = useState(null);
  const [isDragActive, setIsDragActive] = useState(false);
  const [analysisResult, setAnalysisResult] = useState('');
  const [loading, setLoading] = useState(false);

  const handleFileChange = (e) => {
    const selectedFile = e.target.files[0];
    if (selectedFile) {
      setFile(selectedFile);
      setAnalysisResult('');
    }
  };

  const handleDrag = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragActive(e.type === 'dragenter' || e.type === 'dragover');
  };

  const handleDrop = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragActive(false);
    const droppedFile = e.dataTransfer.files[0];
    if (droppedFile) {
      setFile(droppedFile);
      setAnalysisResult('');
    }
  };

  const handleAnalyze = async () => {
    if (!file) return;
    const formData = new FormData();
    formData.append('resume', file);
    setLoading(true);

    try {
      const response = await axios.post('http://localhost:5000/upload-resume', formData);
      const resultText = response.data.candidates?.[0]?.content?.parts?.[0]?.text || JSON.stringify(response.data, null, 2);
      setAnalysisResult(resultText);
    } catch (error) {
      setAnalysisResult(`Error: ${error.response?.data?.error || error.message}`);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="resume-analysis-container">
      <div className="analysis-header">
        <h1>Resume Analysis</h1>
        <p>Upload your resume for AI-powered analysis and interview preparation.</p>
      </div>

      <div className="divider"></div>

      <div 
        className={`upload-area ${isDragActive ? 'active' : ''}`}
        onDragEnter={handleDrag}
        onDragLeave={handleDrag}
        onDragOver={handleDrag}
        onDrop={handleDrop}
      >
        <div className="upload-content">
          <FiUpload className="upload-icon" />
          <h3>Select Resume</h3>
          <p>PDF, DOC, or DOCX (Max 5MB)</p>
          
          <label className="file-input-label">
            <input 
              type="file" 
              accept=".pdf,.doc,.docx" 
              onChange={handleFileChange}
              className="file-input"
            />
            Browse Files
          </label>
        </div>

        {file && (
          <div className="file-preview">
            <FiFile className="file-icon" />
            <span>{file.name}</span>
            <FiCheckCircle className="check-icon" />
          </div>
        )}
      </div>

      <button className="analyze-btn" disabled={!file || loading} onClick={handleAnalyze}>
        {loading ? 'Analyzing...' : 'Analyze Resume'}
      </button>

      {analysisResult && (
        <div className="analysis-card">
          <h3>📄 AI Resume Insights</h3>
          <div className="result-block">
            <pre>{analysisResult}</pre>
          </div>
        </div>
      )}
    </div>
  );
};

export default ResumeAnalysis;
