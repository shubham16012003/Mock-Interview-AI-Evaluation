import React, { useState } from "react";
import axios from "axios";
import "./InterviewApp.css";

const InterviewApp = () => {
  const [resumeFile, setResumeFile] = useState(null);
  const [question, setQuestion] = useState("");
  const [answer, setAnswer] = useState("");
  const [feedback, setFeedback] = useState([]);
  const [interviewStatus, setInterviewStatus] = useState("idle"); // idle | ready | continue | complete
  const [summary, setSummary] = useState("");

  const handleFileChange = (e) => setResumeFile(e.target.files[0]);

  const startInterview = async () => {
    if (!resumeFile) return alert("Please upload a PDF resume.");

    const formData = new FormData();
    formData.append("resume", resumeFile);

    try {
      const res = await axios.post("http://localhost:5000/start-interview", formData);
      setInterviewStatus("ready");
      setQuestion(res.data.first_question);
    } catch (err) {
      alert("Failed to start interview.");
    }
  };

  const submitAnswer = async () => {
    try {
      const res = await axios.post("http://localhost:5000/submit-answer", {
        answer: answer,
      });

      if (res.data.status === "complete") {
        setInterviewStatus("complete");
        setFeedback(res.data.feedback);
        setSummary(res.data.summary);
      } else {
        setInterviewStatus("continue");
        setQuestion(res.data.next_question);
        setFeedback((prev) => [...prev, res.data.feedback]);
      }

      setAnswer("");
    } catch (err) {
      alert("Failed to submit answer.");
    }
  };

  return (
    <div className="interview-container">
      <h1>🎯 AI Interview Practice</h1>

      {interviewStatus === "idle" && (
        <>
          <input type="file" accept="application/pdf" onChange={handleFileChange} />
          <button onClick={startInterview}>Start Interview</button>
        </>
      )}

      {(interviewStatus === "ready" || interviewStatus === "continue") && (
        <>
          <h3>🧠 Question:</h3>
          <p>{question}</p>
          <textarea
            rows="4"
            placeholder="Write your answer here..."
            value={answer}
            onChange={(e) => setAnswer(e.target.value)}
          />
          <button onClick={submitAnswer}>Submit Answer</button>
        </>
      )}

      {interviewStatus === "complete" && (
        <div className="summary-block">
          <h2>✅ Interview Complete</h2>
          <h3>Summary:</h3>
          <pre>{summary}</pre>
          <h3>Detailed Feedback:</h3>
          {feedback.map((item, idx) => (
            <div key={idx} className="feedback-item">
              <p><strong>Q:</strong> {item.question}</p>
              <p><strong>Your Answer:</strong> {item.answer}</p>
              <pre>{item.evaluation}</pre>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default InterviewApp;
